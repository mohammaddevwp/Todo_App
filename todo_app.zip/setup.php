<?php
require_once 'includes/config.php';

// خواندن فایل اسکیما
$sql = file_get_contents('database/schema.sql');

// اجرای دستورات SQL
if (mysqli_multi_query($conn, $sql)) {
    do {
        // خالی کردن نتایج
        if ($result = mysqli_store_result($conn)) {
            mysqli_free_result($result);
        }
    } while (mysqli_next_result($conn));
    
    echo "جداول با موفقیت ایجاد شدند.";
} else {
    echo "خطا در ایجاد جداول: " . mysqli_error($conn);
}

mysqli_close($conn);
?> 