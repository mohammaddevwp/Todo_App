<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
requireLogin();

header('Content-Type: application/json');

$response = [
    'success' => false,
    'message' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $user_id = $_SESSION['user_id'];

    switch ($action) {
        case 'add':
            $title = sanitizeInput($_POST['title']);
            $description = sanitizeInput($_POST['description']);

            if (empty($title)) {
                $response['message'] = 'عنوان وظیفه نمی‌تواند خالی باشد';
                break;
            }

            $sql = "INSERT INTO tasks (user_id, title, description) VALUES (?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "iss", $user_id, $title, $description);

            if (mysqli_stmt_execute($stmt)) {
                $response['success'] = true;
                $response['message'] = 'وظیفه با موفقیت افزوده شد';
            } else {
                $response['message'] = 'خطا در افزودن وظیفه';
            }
            break;

        case 'update':
            $id = (int)$_POST['id'];
            $title = sanitizeInput($_POST['title']);
            $description = sanitizeInput($_POST['description']);

            if (empty($title)) {
                $response['message'] = 'عنوان وظیفه نمی‌تواند خالی باشد';
                break;
            }

            // بررسی مالکیت وظیفه
            $sql = "SELECT id FROM tasks WHERE id = ? AND user_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ii", $id, $user_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($result) === 0) {
                $response['message'] = 'دسترسی غیرمجاز';
                break;
            }

            $sql = "UPDATE tasks SET title = ?, description = ? WHERE id = ? AND user_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ssii", $title, $description, $id, $user_id);

            if (mysqli_stmt_execute($stmt)) {
                $response['success'] = true;
                $response['message'] = 'وظیفه با موفقیت ویرایش شد';
            } else {
                $response['message'] = 'خطا در ویرایش وظیفه';
            }
            break;

        case 'delete':
            $id = (int)$_POST['id'];

            // بررسی مالکیت وظیفه
            $sql = "SELECT id FROM tasks WHERE id = ? AND user_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ii", $id, $user_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($result) === 0) {
                $response['message'] = 'دسترسی غیرمجاز';
                break;
            }

            $sql = "DELETE FROM tasks WHERE id = ? AND user_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ii", $id, $user_id);

            if (mysqli_stmt_execute($stmt)) {
                $response['success'] = true;
                $response['message'] = 'وظیفه با موفقیت حذف شد';
            } else {
                $response['message'] = 'خطا در حذف وظیفه';
            }
            break;

        case 'toggle':
            $id = (int)$_POST['id'];
            $is_completed = (bool)$_POST['is_completed'];

            // بررسی مالکیت وظیفه
            $sql = "SELECT id FROM tasks WHERE id = ? AND user_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ii", $id, $user_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($result) === 0) {
                $response['message'] = 'دسترسی غیرمجاز';
                break;
            }

            $sql = "UPDATE tasks SET is_completed = ? WHERE id = ? AND user_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "iii", $is_completed, $id, $user_id);

            if (mysqli_stmt_execute($stmt)) {
                $response['success'] = true;
                $response['message'] = 'وضعیت وظیفه با موفقیت تغییر کرد';
            } else {
                $response['message'] = 'خطا در تغییر وضعیت وظیفه';
            }
            break;

        default:
            $response['message'] = 'عملیات نامعتبر';
    }
} else {
    $response['message'] = 'متد درخواست نامعتبر';
}

echo json_encode($response);
?> 