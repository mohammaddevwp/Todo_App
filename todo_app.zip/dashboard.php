<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
requireLogin();

// دریافت وظایف کاربر
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM tasks WHERE user_id = ? ORDER BY created_at DESC";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$tasks = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>داشبورد - برنامه مدیریت وظایف</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/vazirmatn@33.003/font-face.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#"><i class="fas fa-tasks me-2"></i>برنامه مدیریت وظایف</a>
            <div class="d-flex align-items-center">
                <span class="text-white me-3"><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                <a href="logout.php" class="btn btn-outline-light"><i class="fas fa-sign-out-alt me-1"></i>خروج</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div id="notifications"></div>
        
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4><i class="fas fa-list-check me-2"></i>وظایف من</h4>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addTaskModal">
                            <i class="fas fa-plus me-1"></i>افزودن وظیفه
                        </button>
                    </div>
                    <div class="card-body">
                        <div id="tasksList">
                            <?php if (empty($tasks)): ?>
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle me-2"></i>هیچ وظیفه‌ای ثبت نشده است.
                                </div>
                            <?php else: ?>
                                <?php foreach ($tasks as $task): ?>
                                    <div class="task-item card mb-3" data-id="<?php echo $task['id']; ?>">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <h5 class="card-title <?php echo $task['is_completed'] ? 'text-decoration-line-through' : ''; ?>">
                                                        <?php echo htmlspecialchars($task['title']); ?>
                                                    </h5>
                                                    <p class="card-text"><?php echo htmlspecialchars($task['description']); ?></p>
                                                </div>
                                                <div class="task-actions">
                                                    <button class="btn btn-sm btn-success toggle-complete" data-id="<?php echo $task['id']; ?>" title="تغییر وضعیت">
                                                        <i class="fas fa-check"></i>
                                                    </button>
                                                    <button class="btn btn-sm btn-primary edit-task" data-id="<?php echo $task['id']; ?>" title="ویرایش">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <button class="btn btn-sm btn-danger delete-task" data-id="<?php echo $task['id']; ?>" title="حذف">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- دکمه تغییر تم -->
    <div class="theme-switcher">
        <button class="theme-btn" title="تغییر تم">
            <i class="fas fa-moon"></i>
        </button>
    </div>

    <!-- Modal افزودن وظیفه -->
    <div class="modal fade" id="addTaskModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-plus-circle me-2"></i>افزودن وظیفه جدید</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="addTaskForm">
                        <div class="mb-3">
                            <label for="title" class="form-label"><i class="fas fa-heading me-1"></i>عنوان</label>
                            <input type="text" class="form-control" id="title" name="title" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label"><i class="fas fa-align-left me-1"></i>توضیحات</label>
                            <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i>انصراف
                    </button>
                    <button type="button" class="btn btn-primary" id="saveTask">
                        <i class="fas fa-save me-1"></i>ذخیره
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal ویرایش وظیفه -->
    <div class="modal fade" id="editTaskModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-edit me-2"></i>ویرایش وظیفه</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="editTaskForm">
                        <input type="hidden" id="editTaskId">
                        <div class="mb-3">
                            <label for="editTitle" class="form-label"><i class="fas fa-heading me-1"></i>عنوان</label>
                            <input type="text" class="form-control" id="editTitle" name="title" required>
                        </div>
                        <div class="mb-3">
                            <label for="editDescription" class="form-label"><i class="fas fa-align-left me-1"></i>توضیحات</label>
                            <textarea class="form-control" id="editDescription" name="description" rows="3"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i>انصراف
                    </button>
                    <button type="button" class="btn btn-primary" id="updateTask">
                        <i class="fas fa-save me-1"></i>ذخیره تغییرات
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html> 