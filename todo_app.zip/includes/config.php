<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'todo_app');

$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD);

if (!$conn) {
    die("اتصال به دیتابیس ناموفق: " . mysqli_connect_error());
}

// ایجاد دیتابیس اگر وجود نداشته باشد
$sql = "CREATE DATABASE IF NOT EXISTS " . DB_NAME;
if (mysqli_query($conn, $sql)) {
    mysqli_select_db($conn, DB_NAME);
} else {
    die("خطا در ایجاد دیتابیس: " . mysqli_error($conn));
}

// تنظیم کدگذاری
mysqli_set_charset($conn, "utf8");
?> 