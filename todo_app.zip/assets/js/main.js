$(document).ready(function() {
    // مدیریت تم‌ها
    const themes = {
        light: {
            '--primary-color': '#4e73df',
            '--secondary-color': '#858796',
            '--success-color': '#1cc88a',
            '--info-color': '#36b9cc',
            '--warning-color': '#f6c23e',
            '--danger-color': '#e74a3b',
            '--light-color': '#f8f9fc',
            '--dark-color': '#5a5c69'
        },
        dark: {
            '--primary-color': '#3757a8',
            '--secondary-color': '#6c757d',
            '--success-color': '#13855c',
            '--info-color': '#2a7f8c',
            '--warning-color': '#c49a2c',
            '--danger-color': '#b83a2e',
            '--light-color': '#212529',
            '--dark-color': '#f8f9fc'
        }
    };

    // بارگذاری تم ذخیره شده
    const savedTheme = localStorage.getItem('theme') || 'light';
    applyTheme(savedTheme);

    // تغییر تم
    $('.theme-btn').click(function() {
        const currentTheme = localStorage.getItem('theme') || 'light';
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        applyTheme(newTheme);
        localStorage.setItem('theme', newTheme);
    });

    function applyTheme(theme) {
        const root = document.documentElement;
        Object.entries(themes[theme]).forEach(([property, value]) => {
            root.style.setProperty(property, value);
        });
    }

    // نمایش اعلان
    function showNotification(message, type = 'success') {
        const notification = $(`
            <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `);
        
        $('#notifications').append(notification);
        
        setTimeout(() => {
            notification.alert('close');
        }, 5000);
    }

    // افزودن وظیفه جدید
    $('#saveTask').click(function() {
        const title = $('#title').val();
        const description = $('#description').val();

        if (!title) {
            showNotification('لطفا عنوان وظیفه را وارد کنید', 'danger');
            return;
        }

        $.ajax({
            url: 'api/tasks.php',
            method: 'POST',
            data: {
                action: 'add',
                title: title,
                description: description
            },
            success: function(response) {
                if (response.success) {
                    showNotification('وظیفه با موفقیت افزوده شد');
                    $('#addTaskModal').modal('hide');
                    setTimeout(() => {
                        location.reload();
                    }, 1000);
                } else {
                    showNotification(response.message, 'danger');
                }
            },
            error: function() {
                showNotification('خطا در ارتباط با سرور', 'danger');
            }
        });
    });

    // ویرایش وظیفه
    $('.edit-task').click(function() {
        const taskId = $(this).data('id');
        const taskItem = $(this).closest('.task-item');
        const title = taskItem.find('.card-title').text();
        const description = taskItem.find('.card-text').text();

        $('#editTaskId').val(taskId);
        $('#editTitle').val(title);
        $('#editDescription').val(description);
        $('#editTaskModal').modal('show');
    });

    $('#updateTask').click(function() {
        const taskId = $('#editTaskId').val();
        const title = $('#editTitle').val();
        const description = $('#editDescription').val();

        if (!title) {
            showNotification('لطفا عنوان وظیفه را وارد کنید', 'danger');
            return;
        }

        $.ajax({
            url: 'api/tasks.php',
            method: 'POST',
            data: {
                action: 'update',
                id: taskId,
                title: title,
                description: description
            },
            success: function(response) {
                if (response.success) {
                    showNotification('وظیفه با موفقیت ویرایش شد');
                    $('#editTaskModal').modal('hide');
                    setTimeout(() => {
                        location.reload();
                    }, 1000);
                } else {
                    showNotification(response.message, 'danger');
                }
            },
            error: function() {
                showNotification('خطا در ارتباط با سرور', 'danger');
            }
        });
    });

    // حذف وظیفه
    $('.delete-task').click(function() {
        if (!confirm('آیا از حذف این وظیفه اطمینان دارید؟')) {
            return;
        }

        const taskId = $(this).data('id');

        $.ajax({
            url: 'api/tasks.php',
            method: 'POST',
            data: {
                action: 'delete',
                id: taskId
            },
            success: function(response) {
                if (response.success) {
                    showNotification('وظیفه با موفقیت حذف شد');
                    setTimeout(() => {
                        location.reload();
                    }, 1000);
                } else {
                    showNotification(response.message, 'danger');
                }
            },
            error: function() {
                showNotification('خطا در ارتباط با سرور', 'danger');
            }
        });
    });

    // تغییر وضعیت انجام وظیفه
    $('.toggle-complete').click(function() {
        const taskId = $(this).data('id');
        const taskItem = $(this).closest('.task-item');
        const isCompleted = taskItem.find('.card-title').hasClass('text-decoration-line-through');

        $.ajax({
            url: 'api/tasks.php',
            method: 'POST',
            data: {
                action: 'toggle',
                id: taskId,
                is_completed: !isCompleted
            },
            success: function(response) {
                if (response.success) {
                    showNotification('وضعیت وظیفه با موفقیت تغییر کرد');
                    setTimeout(() => {
                        location.reload();
                    }, 1000);
                } else {
                    showNotification(response.message, 'danger');
                }
            },
            error: function() {
                showNotification('خطا در ارتباط با سرور', 'danger');
            }
        });
    });
}); 